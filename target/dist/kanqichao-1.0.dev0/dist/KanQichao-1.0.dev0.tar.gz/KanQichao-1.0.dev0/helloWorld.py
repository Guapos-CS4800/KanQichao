import os

def unitTest(out):
    out.write( "Hello World")