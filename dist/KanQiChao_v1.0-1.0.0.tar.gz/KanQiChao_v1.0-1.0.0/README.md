# KanQichao
Handwriting Interpreter for Kanji
